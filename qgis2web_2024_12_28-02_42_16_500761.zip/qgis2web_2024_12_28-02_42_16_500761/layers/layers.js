var wms_layers = [];

var format_PENDIDIKAN_PT_50K_MultiRingBuffer_0 = new ol.format.GeoJSON();
var features_PENDIDIKAN_PT_50K_MultiRingBuffer_0 = format_PENDIDIKAN_PT_50K_MultiRingBuffer_0.readFeatures(json_PENDIDIKAN_PT_50K_MultiRingBuffer_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PENDIDIKAN_PT_50K_MultiRingBuffer_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PENDIDIKAN_PT_50K_MultiRingBuffer_0.addFeatures(features_PENDIDIKAN_PT_50K_MultiRingBuffer_0);
var lyr_PENDIDIKAN_PT_50K_MultiRingBuffer_0 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_PENDIDIKAN_PT_50K_MultiRingBuffer_0, 
                style: style_PENDIDIKAN_PT_50K_MultiRingBuffer_0,
                popuplayertitle: 'PENDIDIKAN_PT_50K_MultiRingBuffer',
                interactive: true,
    title: 'PENDIDIKAN_PT_50K_MultiRingBuffer<br />\
    <img src="styles/legend/PENDIDIKAN_PT_50K_MultiRingBuffer_0_0.png" /> 5<br />\
    <img src="styles/legend/PENDIDIKAN_PT_50K_MultiRingBuffer_0_1.png" /> 10<br />\
    <img src="styles/legend/PENDIDIKAN_PT_50K_MultiRingBuffer_0_2.png" /> 15<br />\
    <img src="styles/legend/PENDIDIKAN_PT_50K_MultiRingBuffer_0_3.png" /> <br />'
        });

        var lyr_GoogleEarthSatelite_1 = new ol.layer.Tile({
            'title': 'Google Earth Satelite',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_JALAN_LN_50K_2 = new ol.format.GeoJSON();
var features_JALAN_LN_50K_2 = format_JALAN_LN_50K_2.readFeatures(json_JALAN_LN_50K_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_JALAN_LN_50K_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_JALAN_LN_50K_2.addFeatures(features_JALAN_LN_50K_2);
var lyr_JALAN_LN_50K_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_JALAN_LN_50K_2, 
                style: style_JALAN_LN_50K_2,
                popuplayertitle: 'JALAN_LN_50K',
                interactive: true,
    title: 'JALAN_LN_50K<br />\
    <img src="styles/legend/JALAN_LN_50K_2_0.png" /> Jalan Arteri<br />\
    <img src="styles/legend/JALAN_LN_50K_2_1.png" /> Jalan Kolektor<br />\
    <img src="styles/legend/JALAN_LN_50K_2_2.png" /> Jalan Lain<br />\
    <img src="styles/legend/JALAN_LN_50K_2_3.png" /> Jalan Lokal<br />\
    <img src="styles/legend/JALAN_LN_50K_2_4.png" /> Jalan Sedang Dibangun<br />\
    <img src="styles/legend/JALAN_LN_50K_2_5.png" /> Jalan Setapak<br />\
    <img src="styles/legend/JALAN_LN_50K_2_6.png" /> <br />'
        });
var format_ADMINISTRASIKECAMATAN_AR_50K_3 = new ol.format.GeoJSON();
var features_ADMINISTRASIKECAMATAN_AR_50K_3 = format_ADMINISTRASIKECAMATAN_AR_50K_3.readFeatures(json_ADMINISTRASIKECAMATAN_AR_50K_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ADMINISTRASIKECAMATAN_AR_50K_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ADMINISTRASIKECAMATAN_AR_50K_3.addFeatures(features_ADMINISTRASIKECAMATAN_AR_50K_3);
var lyr_ADMINISTRASIKECAMATAN_AR_50K_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ADMINISTRASIKECAMATAN_AR_50K_3, 
                style: style_ADMINISTRASIKECAMATAN_AR_50K_3,
                popuplayertitle: 'ADMINISTRASIKECAMATAN_AR_50K',
                interactive: true,
    title: 'ADMINISTRASIKECAMATAN_AR_50K<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_0.png" /> BATAMKOTA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_1.png" /> BATUAJI<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_2.png" /> BATUAMPAR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_3.png" /> BELAKANGPADANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_4.png" /> BENGKONG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_5.png" /> BINTAN TIMUR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_6.png" /> BINTAN UTARA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_7.png" /> BUKITBESTARI<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_8.png" /> BULANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_9.png" /> BURU<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_10.png" /> GALANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_11.png" /> KUALAKAMPAR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_12.png" /> KUNDUR UTARA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_13.png" /> LUBUKBAJA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_14.png" /> MORO<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_15.png" /> NONGSA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_16.png" /> SAGULUNG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_17.png" /> SEKUPANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_18.png" /> SENAYANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_19.png" /> SUNGAIBEDUG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_20.png" /> TANJUNGPINANG KOTA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_21.png" /> TANJUNGPINANG TIMUR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_22.png" /> TELUKBINTAN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_3_23.png" /> <br />'
        });
var format_PENDIDIKAN_PT_50K_4 = new ol.format.GeoJSON();
var features_PENDIDIKAN_PT_50K_4 = format_PENDIDIKAN_PT_50K_4.readFeatures(json_PENDIDIKAN_PT_50K_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PENDIDIKAN_PT_50K_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PENDIDIKAN_PT_50K_4.addFeatures(features_PENDIDIKAN_PT_50K_4);
var lyr_PENDIDIKAN_PT_50K_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_PENDIDIKAN_PT_50K_4, 
                style: style_PENDIDIKAN_PT_50K_4,
                popuplayertitle: 'PENDIDIKAN_PT_50K',
                interactive: true,
                title: '<img src="styles/legend/PENDIDIKAN_PT_50K_4.png" /> PENDIDIKAN_PT_50K'
            });

lyr_PENDIDIKAN_PT_50K_MultiRingBuffer_0.setVisible(true);lyr_GoogleEarthSatelite_1.setVisible(true);lyr_JALAN_LN_50K_2.setVisible(true);lyr_ADMINISTRASIKECAMATAN_AR_50K_3.setVisible(true);lyr_PENDIDIKAN_PT_50K_4.setVisible(true);
var layersList = [lyr_PENDIDIKAN_PT_50K_MultiRingBuffer_0,lyr_GoogleEarthSatelite_1,lyr_JALAN_LN_50K_2,lyr_ADMINISTRASIKECAMATAN_AR_50K_3,lyr_PENDIDIKAN_PT_50K_4];
lyr_PENDIDIKAN_PT_50K_MultiRingBuffer_0.set('fieldAliases', {'mrb_dist': 'mrb_dist', });
lyr_JALAN_LN_50K_2.set('fieldAliases', {'NAMRJL': 'NAMRJL', 'KONRJL': 'KONRJL', 'MATRJL': 'MATRJL', 'FGSRJL': 'FGSRJL', 'UTKRJL': 'UTKRJL', 'TOLRJL': 'TOLRJL', 'WLYRJL': 'WLYRJL', 'AUTRJL': 'AUTRJL', 'KLSRJL': 'KLSRJL', 'SPCRJL': 'SPCRJL', 'JPARJL': 'JPARJL', 'ARHRJL': 'ARHRJL', 'STARJL': 'STARJL', 'KLLRJL': 'KLLRJL', 'MEDRJL': 'MEDRJL', 'LOCRJL': 'LOCRJL', 'JARRJL': 'JARRJL', 'FCODE': 'FCODE', 'REMARK': 'REMARK', 'SRS_ID': 'SRS_ID', 'LCODE': 'LCODE', 'METADATA': 'METADATA', 'SHAPE_Leng': 'SHAPE_Leng', });
lyr_ADMINISTRASIKECAMATAN_AR_50K_3.set('fieldAliases', {'KDPPUM': 'KDPPUM', 'NAMOBJ': 'NAMOBJ', 'REMARK': 'REMARK', 'KDPBPS': 'KDPBPS', 'FCODE': 'FCODE', 'LUASWH': 'LUASWH', 'UUPP': 'UUPP', 'SRS_ID': 'SRS_ID', 'LCODE': 'LCODE', 'METADATA': 'METADATA', 'KDEBPS': 'KDEBPS', 'KDEPUM': 'KDEPUM', 'KDCBPS': 'KDCBPS', 'KDCPUM': 'KDCPUM', 'KDBBPS': 'KDBBPS', 'KDBPUM': 'KDBPUM', 'WADMKD': 'WADMKD', 'WIADKD': 'WIADKD', 'WADMKC': 'WADMKC', 'WIADKC': 'WIADKC', 'WADMKK': 'WADMKK', 'WIADKK': 'WIADKK', 'WADMPR': 'WADMPR', 'WIADPR': 'WIADPR', 'TIPADM': 'TIPADM', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_PENDIDIKAN_PT_50K_4.set('fieldAliases', {'NAMOBJ': 'NAMOBJ', 'LUAS': 'LUAS', 'KATPDK': 'KATPDK', 'JLPDDK': 'JLPDDK', 'FGGPDK': 'FGGPDK', 'REMARK': 'REMARK', 'FCODE': 'FCODE', 'SRS_ID': 'SRS_ID', 'LCODE': 'LCODE', 'METADATA': 'METADATA', 'JJGPDF': 'JJGPDF', 'JNSPDL': 'JNSPDL', });
lyr_PENDIDIKAN_PT_50K_MultiRingBuffer_0.set('fieldImages', {'mrb_dist': 'TextEdit', });
lyr_JALAN_LN_50K_2.set('fieldImages', {'NAMRJL': 'TextEdit', 'KONRJL': 'Range', 'MATRJL': 'Range', 'FGSRJL': 'Range', 'UTKRJL': 'Range', 'TOLRJL': 'Range', 'WLYRJL': 'Range', 'AUTRJL': 'Range', 'KLSRJL': 'Range', 'SPCRJL': 'Range', 'JPARJL': 'Range', 'ARHRJL': 'Range', 'STARJL': 'Range', 'KLLRJL': 'TextEdit', 'MEDRJL': 'Range', 'LOCRJL': 'Range', 'JARRJL': 'Range', 'FCODE': 'TextEdit', 'REMARK': 'TextEdit', 'SRS_ID': 'TextEdit', 'LCODE': 'TextEdit', 'METADATA': 'TextEdit', 'SHAPE_Leng': 'TextEdit', });
lyr_ADMINISTRASIKECAMATAN_AR_50K_3.set('fieldImages', {'KDPPUM': 'TextEdit', 'NAMOBJ': 'TextEdit', 'REMARK': 'TextEdit', 'KDPBPS': 'TextEdit', 'FCODE': 'TextEdit', 'LUASWH': 'TextEdit', 'UUPP': 'TextEdit', 'SRS_ID': 'TextEdit', 'LCODE': 'TextEdit', 'METADATA': 'TextEdit', 'KDEBPS': 'TextEdit', 'KDEPUM': 'TextEdit', 'KDCBPS': 'TextEdit', 'KDCPUM': 'TextEdit', 'KDBBPS': 'TextEdit', 'KDBPUM': 'TextEdit', 'WADMKD': 'TextEdit', 'WIADKD': 'TextEdit', 'WADMKC': 'TextEdit', 'WIADKC': 'TextEdit', 'WADMKK': 'TextEdit', 'WIADKK': 'TextEdit', 'WADMPR': 'TextEdit', 'WIADPR': 'TextEdit', 'TIPADM': 'Range', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_PENDIDIKAN_PT_50K_4.set('fieldImages', {'NAMOBJ': 'TextEdit', 'LUAS': 'TextEdit', 'KATPDK': 'Range', 'JLPDDK': 'Range', 'FGGPDK': 'Range', 'REMARK': 'TextEdit', 'FCODE': 'TextEdit', 'SRS_ID': 'TextEdit', 'LCODE': 'TextEdit', 'METADATA': 'TextEdit', 'JJGPDF': 'Range', 'JNSPDL': 'Range', });
lyr_PENDIDIKAN_PT_50K_MultiRingBuffer_0.set('fieldLabels', {'mrb_dist': 'inline label - always visible', });
lyr_JALAN_LN_50K_2.set('fieldLabels', {'NAMRJL': 'no label', 'KONRJL': 'no label', 'MATRJL': 'no label', 'FGSRJL': 'no label', 'UTKRJL': 'no label', 'TOLRJL': 'no label', 'WLYRJL': 'no label', 'AUTRJL': 'no label', 'KLSRJL': 'no label', 'SPCRJL': 'no label', 'JPARJL': 'no label', 'ARHRJL': 'no label', 'STARJL': 'no label', 'KLLRJL': 'no label', 'MEDRJL': 'no label', 'LOCRJL': 'no label', 'JARRJL': 'no label', 'FCODE': 'no label', 'REMARK': 'no label', 'SRS_ID': 'no label', 'LCODE': 'no label', 'METADATA': 'no label', 'SHAPE_Leng': 'no label', });
lyr_ADMINISTRASIKECAMATAN_AR_50K_3.set('fieldLabels', {'KDPPUM': 'no label', 'NAMOBJ': 'inline label - always visible', 'REMARK': 'no label', 'KDPBPS': 'no label', 'FCODE': 'no label', 'LUASWH': 'no label', 'UUPP': 'no label', 'SRS_ID': 'no label', 'LCODE': 'no label', 'METADATA': 'no label', 'KDEBPS': 'no label', 'KDEPUM': 'no label', 'KDCBPS': 'no label', 'KDCPUM': 'no label', 'KDBBPS': 'no label', 'KDBPUM': 'no label', 'WADMKD': 'no label', 'WIADKD': 'no label', 'WADMKC': 'no label', 'WIADKC': 'no label', 'WADMKK': 'no label', 'WIADKK': 'no label', 'WADMPR': 'no label', 'WIADPR': 'no label', 'TIPADM': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_PENDIDIKAN_PT_50K_4.set('fieldLabels', {'NAMOBJ': 'no label', 'LUAS': 'inline label - always visible', 'KATPDK': 'inline label - always visible', 'JLPDDK': 'inline label - always visible', 'FGGPDK': 'header label - visible with data', 'REMARK': 'inline label - always visible', 'FCODE': 'inline label - always visible', 'SRS_ID': 'inline label - always visible', 'LCODE': 'inline label - always visible', 'METADATA': 'inline label - always visible', 'JJGPDF': 'inline label - always visible', 'JNSPDL': 'inline label - always visible', });
lyr_PENDIDIKAN_PT_50K_4.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});